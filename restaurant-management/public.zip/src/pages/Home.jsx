import React from "react";
import { HomeContainer } from "../../components";

function Home(){
    return(
        <>
            <HomeContainer />
        </>

    );
}

export default Home;